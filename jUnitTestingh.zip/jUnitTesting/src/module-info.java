module jUnitTesting {
	exports jUnitTestingPackage;

	requires org.junit.jupiter.api;
	requires junit;
}