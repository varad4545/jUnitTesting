package jUnitTestingPackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class testAddStrings {

	@Test
	public void test() {
		jUnitFunction junits=new jUnitFunction();
		String resul=junits.addStrings("Java", "Project");
		assertEquals("JavaProject",resul);
	}

}
