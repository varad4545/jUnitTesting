package jUnitTestingPackage;

public class jUnitFunction {
	public int addNumbers(int n1,int n2) {
		return n1+n2;
	}
	public String addStrings(String s1,String s2) {
		return s1+s2;
	}


}
